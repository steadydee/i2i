"""
Backend package marker.

Keep this file minimal to avoid circular-import headaches.
"""
